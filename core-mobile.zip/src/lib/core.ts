import {
  StubCoreClient,
  defaultFixture,
  type CoreClient,
  type ResolvedContext,
  type StubFixture,
} from '@beorchid/core-sdk';

/**
 * THE CORE API SEAM, and the composition root that picks an implementation.
 *
 * Section 5.5: this app has no database access to `core` of any kind, not even
 * read — and unlike core-web it has no database access at all, to any schema.
 * Every fact about who the user is, which organisation they are acting in, and
 * what they may do arrives through this client.
 */

/** This app's key in core.apps. Also its schema name and grant scope. */
export const APP_KEY = 'core_mobile';

let client: CoreClient | null = null;

/**
 * The fixture core-web's stub uses, with this app's own permission set added.
 *
 * The SDK's defaultFixture() names core_web and a placeholder `second_app`, so
 * resolving core_mobile against it unmodified returns null permissions — a
 * correct default deny (Section 6.1a), but it would leave this app's whole
 * reason for existing invisible. Alice, Acme and the membership are reused
 * exactly as core-web has them, because the demonstration depends on it being
 * the same person in the same organisation at the same moment.
 *
 * `leads:read` alone is the `viewer` contrast to core-web's admin set. Same
 * person, full access on one surface, read-only on the other (Section 6.1a).
 */
function mobileFixture(): StubFixture {
  const fixture = defaultFixture();
  return {
    ...fixture,
    permissionsByApp: {
      ...fixture.permissionsByApp,
      [APP_KEY]: ['leads:read'],
    },
  };
}

export function coreClient(): CoreClient {
  if (client) return client;

  /**
   * Deliberately NOT the guide's `baseUrl && apiKey` selection.
   *
   * core-web keeps CORE_API_KEY server-side where the browser never sees it. A
   * mobile app has no server side: any key in the bundle is extractable by
   * anyone who downloads it, and the Core API key reads any user in the system.
   * Reading an EXPO_PUBLIC_CORE_API_KEY here would mean that merely setting it
   * in .env silently ships that credential — so this file does not read it, and
   * there is no code path that can.
   *
   * How mobile authenticates to Core API is an open decision awaiting a written
   * client answer. Setting the URL fails loudly rather than quietly falling back
   * to the stub, so nobody concludes they are running against a real Core API
   * when they are not.
   */
  const baseUrl = process.env.EXPO_PUBLIC_CORE_API_URL;
  if (baseUrl) {
    throw new Error(
      `EXPO_PUBLIC_CORE_API_URL is set (${baseUrl}), but mobile has no agreed way to ` +
        'authenticate to Core API yet. See Section 2.2 of the build guide. Unset it to ' +
        'run against the fixture.',
    );
  }

  client = new StubCoreClient(mobileFixture());
  return client;
}

/**
 * Pinned false, and named to match core-web so the screens read alike.
 *
 * It becomes a real check once Section 2.2 is answered and there is something
 * for it to be true about.
 */
export function isCoreApiConfigured(): boolean {
  return false;
}

/**
 * Three states, not two, because "signed out" and "signed in but not yet known
 * to Core" need different handling and produce different screens.
 *
 * The third state is ordinary rather than exceptional: Clerk creates the
 * account, and the webhook that projects it into core.users arrives moments
 * later (Section 4.6). A person can legitimately open the app in between.
 */
export type CurrentContext =
  | { state: 'signed-out' }
  | { state: 'unlinked'; clerkUserId: string }
  | { state: 'resolved'; context: ResolvedContext };
