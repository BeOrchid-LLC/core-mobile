# Registering `core_mobile` in Core

**Not executed.** This is written up rather than run, for two reasons:

1. It requires changes to `core-api` — extending `seed-dev.ts` and adding to
   `APP_API_KEYS` in its `.env`. `core-api` is under review and must not receive
   unagreed changes.
2. The build guide's own §10 records that the Core API authentication question
   (§2.2) blocks Section 7 onward. Registering the app is only useful once there
   is an agreed way for mobile to call Core API, and there is not one yet.

Nothing in the app is blocked on this. `core-mobile` runs against
`StubCoreClient` and the §16 demonstration works from the fixtures alone — see
the README.

## Steps, when it is time

### 1. Register the app

```bash
cd core-api
npx tsx scripts/connect-app.ts core_mobile "Core Mobile Reference App"
```

`core_mobile` needs a row in `core.apps` before anything resolves against a real
Core API. The key is contractually locked: the repo is `core-mobile`, the app key
is `core_mobile`, and the schema takes the app name with no prefix (§15.2).

### 2. Give Alice a `viewer` assignment

```bash
npm run db:grant-dev-access -- user_2ab9k1 core_mobile viewer
```

**The role must be stated explicitly.** `grant-dev-access.ts` signature is
`<clerk_user_id> [app_key] [role_key]` and `role_key` defaults to `admin`. The
build guide's §6.2 prints this command without the role, which would make Alice
an admin on mobile — the same set she holds in `core_web`, and the §16
demonstration would show nothing.

To make it survive a clean seed, `seed-dev.ts` needs the same assignment added.
That is a `core-api` change and is left for whoever owns that repository.

### 3. API key

Add the app key to `APP_API_KEYS` in `core-api`'s `.env`. This currently requires
a Core API restart, which is itself on the defect list.

**Do not put the resulting key in this app.** There is no
`EXPO_PUBLIC_CORE_API_KEY` and `src/lib/core.ts` has no code path that reads one.
Whatever §2.2 resolves to, a Core API key in the bundle is not it.

## Known defects this will hit

Reported, none fixed at the time of writing. Work around them; do not repair them
here.

| Defect | Effect |
|---|---|
| `connect-app.ts` cannot run as the migration role — no `INSERT` on `core.apps`, no `CREATEROLE` | Works locally as superuser only. Will fail in staging. |
| No sequence grants issued for app schemas | A `bigserial` insert fails with `permission denied for sequence` |
| `core-api` webhook handler broken — `svix` v2's `verify()` returns `undefined` | Every Clerk event 500s, so identity will not populate from webhooks. Use `npm run db:reconcile` and `npm run db:seed-dev`. |
| `/v1/permissions/resolve` accepts an arbitrary `app_id` with no check against the calling app | Directly relevant to §2.2: it is why the "separate low-privilege mobile key" option is the weakest of the three |

## Per-app database role naming

§15.2 leaves this open and the guide assumes `core_mobile_rw`. Note that this app
has **no database role at all** and needs none — it holds no database connection.
The name only matters if `core_mobile` is ever given a schema of its own.
